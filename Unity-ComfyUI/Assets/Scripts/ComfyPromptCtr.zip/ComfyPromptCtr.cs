using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;
using System.Globalization;
using TMPro;

[System.Serializable]
public class ResponseData {
    public string prompt_id;
}

public class ComfyPromptCtr : MonoBehaviour {

    [TextArea (3,20)]
    public string promptJson;

    [Header("Main Settings")]    
    // Main
    public TMP_Dropdown checkpointDropdown;
    public TMP_InputField promptInput;
    public TMP_Dropdown loraDropdown;
    public TMP_InputField loraWeightInput;
    public TMP_InputField resXInput;
    public TMP_InputField resYInput;
    public TMP_InputField sampler1StepsInput;
    public TMP_InputField sampler1CFGInput;
    public TMP_InputField samplerDenoise1Input;

    //IPAdapter
    public TMP_InputField ipWeightInput;
    public TMP_Dropdown ipImage1Dropdown;
    public TMP_Dropdown ipImage2Dropdown;

    //ControlNet
    public TMP_InputField cnWeightInput;
    public TMP_Dropdown controlnetDropdown;
    public TMP_Dropdown cnImageDropdown;

    //Upscaler
    public TMP_InputField postWeightInput;
    public TMP_Dropdown upscalerDropdown;

    //Final Sampler
    public TMP_InputField resXfinalInput;
    public TMP_InputField resYfinalInput;
    public TMP_InputField sampler2StepsInput;
    public TMP_InputField sampler2CFGInput;
    public TMP_InputField sampler2DenoiseInput;



    private void Start() {
    }
  
    void Update() {
        if (Input.GetKeyDown(KeyCode.Space)) {
            TestStaticValues();
            Debug.Log("ComfyUIQueuePrompt called");
        }
    }

    public void ComfyUIQueuePrompt() {
        string checkpoint = checkpointDropdown.options[checkpointDropdown.value].text;
        string prompt = promptInput.text;
        string lora = loraDropdown.options[loraDropdown.value].text;
        float loraWeight = float.Parse(loraWeightInput.text, CultureInfo.InvariantCulture);
        int resX = int.Parse(resXInput.text, CultureInfo.InvariantCulture);
        int resY = int.Parse(resYInput.text, CultureInfo.InvariantCulture);
        int sampler1steps = int.Parse(sampler1StepsInput.text, CultureInfo.InvariantCulture);
        float sampler1cfg = float.Parse(sampler1CFGInput.text, CultureInfo.InvariantCulture);
        float sampler1denoise = float.Parse(samplerDenoise1Input.text, CultureInfo.InvariantCulture);

        float ipWeight = float.Parse(ipWeightInput.text, CultureInfo.InvariantCulture);
        string ipImage1 =  ipImage1Dropdown.options[ipImage1Dropdown.value].text;
        string ipImage2 =  ipImage2Dropdown.options[ipImage2Dropdown.value].text;

        float cnWeight = float.Parse(cnWeightInput.text, CultureInfo.InvariantCulture);
        string controlnet =  controlnetDropdown.options[controlnetDropdown.value].text;
        string cnImage =  cnImageDropdown.options[cnImageDropdown.value].text;

        float postWeight = float.Parse(postWeightInput.text, CultureInfo.InvariantCulture);
        string upscaler =  upscalerDropdown.options[upscalerDropdown.value].text;

        int resXfinal = int.Parse(resXfinalInput.text, CultureInfo.InvariantCulture);
        int resYfinal = int.Parse(resYfinalInput.text, CultureInfo.InvariantCulture);
        int sampler2Steps = int.Parse(sampler2StepsInput.text, CultureInfo.InvariantCulture);
        float sampler2CFG = float.Parse(sampler2CFGInput.text, CultureInfo.InvariantCulture);
        float sampler2Denoise = float.Parse(sampler2DenoiseInput.text, CultureInfo.InvariantCulture);

        StartCoroutine(QueuePromptCoroutine(checkpoint, prompt, lora, loraWeight, resX, resY, sampler1steps, sampler1cfg, sampler1denoise, ipWeight, ipImage1, ipImage2, cnWeight, controlnet, cnImage, postWeight, upscaler, resXfinal, resYfinal, sampler2Steps, sampler2CFG, sampler2Denoise));

        //StartCoroutine(QueuePromptCoroutine("sdxl_realvisxlV50_v50LightingBakedvae.safetensors", "Tigers", "resXfinal-fluff.safetensors", 0.6, 1024, 1024, 12, 1.8, 0.25, 0.6, "1.png", "2.png", 0.5, "control_v11p_sd15_lineart_fp16.safetensors", "3.png", "0.66", "4x-UltraSharp.pth", 1920, 1920, 8, 1.2, 0.2));
    }

    public void TestStaticValues() {
        StartCoroutine(QueuePromptCoroutine(
            "sdxl_realvisxlV50_v50LightingBakedvae.safetensors",    // checkpoint
            "Tigers",                                               // prompt
            "ral-fluff.safetensors",                                // lora
            0.6f,                                              // loraWeight
            1024,                                              // resX
            1024,                                              // resY
            12,                                                // sampler1steps
            1.8f,                                              // sampler1cfg
            0.25f,                                             // sampler1denoise
            0.6f,                                              // ipWeight
            "1.png",                                           // ipImage1
            "2.png",                                           // ipImage2
            0.5f,                                              // cnWeight
            "control_v11p_sd15_lineart_fp16.safetensors",      // controlnet
            "3.png",                                           // cnImage
            0.66f,                                             // postWeight
            "4x-UltraSharp.pth",                               // upscaler
            1920,                                              // resXfinal
            1920,                                              // resYfinal
            8,                                                 // sampler2Steps
            1.2f,                                              // sampler2CFG
            0.2f                                               // sampler2Denoise
        ));
    }

    private IEnumerator QueuePromptCoroutine(string checkpoint, string prompt, string lora, float loraWeight, int resX, int resY, int sampler1steps, float sampler1cfg, float sampler1denoise, float ipWeight, string ipImage1, string ipImage2, float cnWeight, string controlnet, string cnImage, float postWeight, string upscaler, int resXfinal, int resYfinal, int sampler2Steps, float sampler2CFG, float sampler2denoise){
        string url = "http://127.0.0.1:8188/prompt";
        
        // Get the JSON template and replace placeholders with actual values
        string promptText = GeneratePromptJson();
        promptText = promptText.Replace("CHECKPOINT", checkpoint);
        /*
                               .Replace("PROMPT", prompt)
                               .Replace("LORA", lora)
                               .Replace("LORAWEIGHT", loraWeight.ToString(CultureInfo.InvariantCulture))

                               .Replace("RESX", resX.ToString(CultureInfo.InvariantCulture))
                               .Replace("RESY", resY.ToString(CultureInfo.InvariantCulture))
                               .Replace("1SAMPLERSTEPS", sampler1steps.ToString(CultureInfo.InvariantCulture))
                               .Replace("1SAMPLERCFG", sampler1cfg.ToString(CultureInfo.InvariantCulture))
                               .Replace("1SAMPLERDENOISE", sampler1denoise.ToString(CultureInfo.InvariantCulture))
                               
                               .Replace("IPWEIGHT", ipWeight.ToString(CultureInfo.InvariantCulture))
                               .Replace("IPIMAGE1", ipImage1.ToString(CultureInfo.InvariantCulture))
                               .Replace("IPIMAGE2", ipImage2.ToString(CultureInfo.InvariantCulture))

                               .Replace("CONTROLNETWEIGHT", cnWeight.ToString(CultureInfo.InvariantCulture))
                               .Replace("CONTROLNET", controlnet.ToString(CultureInfo.InvariantCulture))
                               .Replace("CONTROLNETIMAGE", cnImage.ToString(CultureInfo.InvariantCulture))

                               .Replace("POSTPROCESSWEIGHT", postWeight.ToString(CultureInfo.InvariantCulture))
                               .Replace("UPSCALER", upscaler.ToString(CultureInfo.InvariantCulture))

                               .Replace("FINALRESX", resXfinal.ToString(CultureInfo.InvariantCulture))
                               .Replace("FINALRESY", resYfinal.ToString(CultureInfo.InvariantCulture))
                               .Replace("2SAMPLERSTEPS", sampler2Steps.ToString(CultureInfo.InvariantCulture))
                               .Replace("2SAMPLERCFG", sampler2CFG.ToString(CultureInfo.InvariantCulture))
                               .Replace("2SAMPLERDENOISE", sampler2denoise.ToString(CultureInfo.InvariantCulture));
        */
        UnityWebRequest request = new UnityWebRequest(url, "POST");
        byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(promptText);
        request.uploadHandler = (UploadHandler)new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");

        yield return request.SendWebRequest();

        if (request.result != UnityWebRequest.Result.Success) {
            Debug.Log(request.error);
            //ComfyUIQueuePrompt(finalPrompt);
        } else {
            //Debug.Log("Prompt queued successfully." + request.downloadHandler.text);
            ResponseData data = JsonUtility.FromJson<ResponseData>(request.downloadHandler.text);
            Debug.Log("Prompt ID: " + data.prompt_id);
            GetComponent<ComfyWebsocket>().promptID = data.prompt_id;
        }
    }
    
    private string GeneratePromptJson() {
        string guid = Guid.NewGuid().ToString();
        string promptJsonWithGuid = $@"
        {{
            ""id"": ""{guid}"",
            ""prompt"": {promptJson}
        }}";
        return promptJsonWithGuid;
    }
}
